#ifndef __AFFICHE_ARBRE_ABSTRAIT__
#define __AFFICHE_ARBRE_ABSTRAIT__

#include "syntabs.h"

void affiche_n_prog(n_prog *n);

#endif

