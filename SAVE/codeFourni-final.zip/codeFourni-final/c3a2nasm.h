#ifndef __C3A2NASM__
#define __C3A2NASM__

void c3a2nasm_generer();


#endif
